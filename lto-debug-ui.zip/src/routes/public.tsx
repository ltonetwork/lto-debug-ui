//import { Navigate } from "react-router-dom";

import Debug from "../screens/debug";

export const publicRoutes = [
  {
    path: "/debug",
    element: <Debug />,
  },
];
